import React from "react";

const Footer = () => {
  return (
    <footer className="bg-gray-200 dark:bg-gray-900 text-center py-6 mt-10">
      <p className="text-gray-700 dark:text-gray-400">
        © {new Date().getFullYear()} Arvind's Portfolio | Built with ❤️ using React & Tailwind
      </p>
    </footer>
  );
};

export default Footer;
