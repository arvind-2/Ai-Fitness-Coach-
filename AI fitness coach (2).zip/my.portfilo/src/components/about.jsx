import React from "react";
import { motion } from "framer-motion";

const About = () => {
  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-900">
      <div className="max-w-5xl mx-auto px-6 text-center">
        <motion.h2 
          initial={{ opacity: 0, y: -30 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 1 }}
          className="text-4xl font-bold text-gray-900 dark:text-white mb-6"
        >
          About Me
        </motion.h2>
        <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
          I'm <span className="font-semibold text-blue-600 dark:text-blue-400">Arvind</span>, 
          an aspiring Software Engineer passionate about AI, Web Development, and Game Development.  
          I love building innovative projects like AI-powered fitness platforms, multiplayer games, and full-stack applications.  
          Skilled in <span className="font-semibold">React, Node.js, MongoDB, Unity, and TensorFlow.js</span>.  
          Always excited to learn, experiment, and create impactful solutions.
        </p>
      </div>
    </section>
  );
};

export default About;
