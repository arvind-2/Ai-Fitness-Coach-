import React from "react";
import { motion } from "framer-motion";

const Contact = () => {
  return (
    <section id="contact" className="py-20 bg-gray-100 dark:bg-gray-900">
      <div className="max-w-5xl mx-auto px-6 text-center">
        <motion.h2 
          initial={{ opacity: 0, y: -30 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 1 }}
          className="text-4xl font-bold text-gray-900 dark:text-white mb-6"
        >
          Contact Me
        </motion.h2>
        <p className="text-lg text-gray-600 dark:text-gray-300 mb-8">
          Feel free to reach out for collaborations or opportunities 👇
        </p>
        <form className="max-w-2xl mx-auto bg-white dark:bg-gray-800 shadow-lg rounded-2xl p-6">
          <input 
            type="text" 
            placeholder="Your Name" 
            className="w-full mb-4 p-3 rounded-lg border dark:bg-gray-700 dark:text-white" 
          />
          <input 
            type="email" 
            placeholder="Your Email" 
            className="w-full mb-4 p-3 rounded-lg border dark:bg-gray-700 dark:text-white" 
          />
          <textarea 
            rows="5" 
            placeholder="Your Message" 
            className="w-full mb-4 p-3 rounded-lg border dark:bg-gray-700 dark:text-white"
          ></textarea>
          <button 
            type="submit" 
            className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700"
          >
            Send Message
          </button>
        </form>
        <div className="mt-6 flex justify-center gap-6 text-2xl">
          <a href="mailto:youremail@example.com" className="text-gray-600 dark:text-gray-300 hover:text-blue-600">📧</a>
          <a href="https://github.com/yourgithub" target="_blank" rel="noopener noreferrer" className="text-gray-600 dark:text-gray-300 hover:text-blue-600">🐙</a>
          <a href="https://linkedin.com/in/yourlinkedin" target="_blank" rel="noopener noreferrer" className="text-gray-600 dark:text-gray-300 hover:text-blue-600">💼</a>
        </div>
      </div>
    </section>
  );
};

export default Contact;
