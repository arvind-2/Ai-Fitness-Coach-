import React from "react";
import { motion } from "framer-motion";

const Hero = () => {
  return (
    <section id="home" className="min-h-screen flex flex-col justify-center items-center bg-gray-100 dark:bg-gray-900">
      <motion.h1 
        initial={{ opacity: 0, y: -50 }} 
        animate={{ opacity: 1, y: 0 }} 
        transition={{ duration: 1 }}
        className="text-5xl font-bold text-gray-900 dark:text-white"
      >
        Hi, I'm Arvind 👋
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        transition={{ delay: 0.5, duration: 1 }}
        className="mt-4 text-xl text-gray-600 dark:text-gray-300"
      >
        Aspiring Software Engineer | AI & Web Developer
      </motion.p>
      <div className="mt-6 flex gap-4">
        <a href="#projects" className="px-6 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700">View Projects</a>
        <a href="/resume.pdf" download className="px-6 py-2 border border-blue-600 text-blue-600 rounded-lg shadow hover:bg-blue-600 hover:text-white">Download Resume</a>
      </div>
    </section>
  );
};

export default Hero;
