import React from "react";
import { motion } from "framer-motion";

const projects = [
  {
    title: "AI Fitness Coach Website",
    description: "AI-powered fitness platform with real-time webcam pose detection, calorie tracking, wrong-exercise correction, workout generator, and Firebase login.",
    tech: "React, Tailwind, TensorFlow.js, Firebase",
    link: "#", // 👉 yaha tum live project/GitHub ka link daalna
  },
  {
    title: "BattleMan – Multiplayer 3D Game",
    description: "Cross-platform multiplayer 3D game with Photon PUN 2, real-time sync, lobby, and chat system.",
    tech: "Unity, C#, Photon PUN 2",
    link: "#",
  },
  {
    title: "Perfume Shop Full-Stack Website",
    description: "MERN stack perfume shop with homepage, product details, reviews, and MongoDB integration.",
    tech: "React, Node.js, MongoDB, Express",
    link: "#",
  },
  {
    title: "Scientific Calculator Web App",
    description: "Responsive calculator with dark mode, square root, power functions, and advanced operations.",
    tech: "HTML, CSS, JavaScript",
    link: "#",
  },
  {
    title: "Personal Portfolio Website",
    description: "Modern responsive personal portfolio website with dark theme design.",
    tech: "HTML, CSS",
    link: "#",
  },
];

const Projects = () => {
  return (
    <section id="projects" className="py-20 bg-gray-50 dark:bg-gray-800">
      <div className="max-w-6xl mx-auto px-6">
        <motion.h2 
          initial={{ opacity: 0, y: -30 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 1 }}
          className="text-4xl font-bold text-center text-gray-900 dark:text-white mb-12"
        >
          My Projects
        </motion.h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div 
              key={index}
              whileHover={{ scale: 1.05 }}
              className="bg-white dark:bg-gray-900 shadow-lg rounded-2xl p-6 flex flex-col justify-between"
            >
              <div>
                <h3 className="text-2xl font-semibold text-gray-800 dark:text-white">{project.title}</h3>
                <p className="mt-3 text-gray-600 dark:text-gray-300">{project.description}</p>
                <p className="mt-2 text-sm text-blue-600 dark:text-blue-400">Tech: {project.tech}</p>
              </div>
              <a 
                href={project.link} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700 text-center"
              >
                View Project
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
