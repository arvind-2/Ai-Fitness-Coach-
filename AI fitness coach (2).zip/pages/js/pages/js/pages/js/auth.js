function registerUser() {
    const email = document.getElementById("regEmail").value;
    const password = document.getElementById("regPassword").value;
  
    firebase.auth().createUserWithEmailAndPassword(email, password)
      .then(userCredential => {
        alert("Registered successfully!");
        window.location.href = "login.html";
      })
      .catch(error => alert(error.message));
  }
  
  function loginUser() {
    const email = document.getElementById("loginEmail").value;
    const password = document.getElementById("loginPassword").value;
  
    firebase.auth().signInWithEmailAndPassword(email, password)
      .then(userCredential => {
        alert("Logged in!");
        window.location.href = "my-workout.html";  // Redirect to dashboard
      })
      .catch(error => alert(error.message));
  }
  