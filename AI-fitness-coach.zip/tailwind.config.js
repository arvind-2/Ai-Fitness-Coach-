module.exports = {
    darkMode: 'class', // Enable class-based dark mode
    content: ['./index.html'],
    theme: {
      extend: {},
    },
    plugins: [],
  }
  darkMode: 'class' // NOT 'media'
  darkMode: 'class'

