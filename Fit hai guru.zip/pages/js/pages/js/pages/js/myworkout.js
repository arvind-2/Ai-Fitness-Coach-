function saveWorkout() {
    const input = document.getElementById("workoutInput").value;
    if (!input) return;
  
    let workouts = JSON.parse(localStorage.getItem("workouts")) || [];
    workouts.push(input);
    localStorage.setItem("workouts", JSON.stringify(workouts));
    document.getElementById("workoutInput").value = "";
    loadWorkouts();
  }
  
  function loadWorkouts() {
    const list = document.getElementById("workoutList");
    const workouts = JSON.parse(localStorage.getItem("workouts")) || [];
    list.innerHTML = workouts.map(w => `<li>${w}</li>`).join("");
  }
  
  window.onload = loadWorkouts;
  